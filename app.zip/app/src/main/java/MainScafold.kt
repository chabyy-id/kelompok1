package com.example.klp1scaffold

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

// =========================
// DATA ANGGOTA
// =========================
data class Member(
    val nama: String,
    val nim: String,
    val prodi: String,
    val email: String,
    val phone: String,
    val skills: List<Pair<String, Float>>
)

val anggota = listOf(
    Member(
        "Zalsah Sabila", "2023230018", "Sistem Informasi",
        "zalsahsabila03@gmail.com", "081225827769",
        listOf(
            "Kotlin" to 0.9f,
            "UI/UX" to 0.8f,
            "Canva" to 0.95f,
            "SQL" to 0.7f,
            "Public Speaking" to 0.85f
        )
    ),
    Member(
        "Syalwa Syahravinola", "2023230047", "Sistem Informasi",
        "syalwa@gmail.com", "0822xxxx",
        listOf(
            "Python" to 0.8f,
            "Figma" to 0.9f,
            "Canva" to 0.9f,
            "HTML" to 0.7f,
            "Leadership" to 0.85f
        )
    ),
    Member(
        "Andi Muhammah Rifky", "2023230053", "Sistem Informatika",
        "rifky@gmail.com", "0833xxxx",
        listOf(
            "Java" to 0.85f,
            "Backend" to 0.8f,
            "Networking" to 0.7f,
            "Linux" to 0.75f,
            "Problem Solving" to 0.9f
        )
    ),
    Member(
        "Dhilam Anugrah", "2023230039", "Sistem Informasi",
        "dhilam@gmail.com", "0844xxxx",
        listOf(
            "Android Studio" to 0.88f,
            "Kotlin" to 0.9f,
            "UI Design" to 0.9f,
            "Editing" to 0.95f,
            "Teamwork" to 0.92f
        )
    )
)

// =========================
// SCAFFOLD UTAMA
// =========================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScafold() {
    var isDarkTheme by rememberSaveable { mutableStateOf(false) }
    var selectedMemberIndex by remember { mutableIntStateOf(0) }
    var selectedPageIndex by remember { mutableIntStateOf(0) }

    val member = anggota[selectedMemberIndex]

    MaterialTheme(colorScheme = if (isDarkTheme) darkColorScheme() else lightColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Profil Anggota", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.padding(horizontal = 8.dp),
                    colors = TopAppBarDefaults.largeTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { isDarkTheme = !isDarkTheme }) {
                    Text("🌓")
                }
            },
            bottomBar = {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    anggota.forEachIndexed { index, m ->
                        Button(
                            onClick = { selectedMemberIndex = index },
                            shape = RoundedCornerShape(50),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedMemberIndex == index)
                                    MaterialTheme.colorScheme.primary
                                else
                                    MaterialTheme.colorScheme.surfaceVariant
                            )
                        ) {
                            Text(
                                m.nama.split(" ")[0],
                                color = if (selectedMemberIndex == index)
                                    MaterialTheme.colorScheme.onPrimary
                                else
                                    MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding)) {
                PageSelector(selectedPageIndex, onChange = { selectedPageIndex = it })
                Spacer(Modifier.height(16.dp))

                when (selectedPageIndex) {
                    0 -> AboutPage(member)
                    1 -> SkillsPage(member)
                    2 -> ContactPage(member)
                }
            }
        }
    }
}

// =========================
// DROPDOWN HALAMAN
// =========================
@Composable
fun PageSelector(selected: Int, onChange: (Int) -> Unit) {
    val pages = listOf("About", "Skills", "Contact")
    var expanded by remember { mutableStateOf(false) }

    Box(Modifier.padding(16.dp)) {
        Button(onClick = { expanded = true }) {
            Text("Pilih Halaman: ${pages[selected]}")
        }

        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            pages.forEachIndexed { index, page ->
                DropdownMenuItem(
                    text = { Text(page) },
                    onClick = {
                        onChange(index)
                        expanded = false
                    }
                )
            }
        }
    }
}

// =========================
// PAGE ABOUT
// =========================
@Composable
fun AboutPage(member: Member) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        // =======================
        // INTRO APLIKASI
        // =======================
        Text(
            "Aplikasi Profil Kelompok",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(Modifier.height(6.dp))

        Text(
            "Aplikasi ini dibuat untuk menampilkan biodata, skill, dan kontak dari setiap anggota kelompok secara modern menggunakan Jetpack Compose.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(20.dp))

        // =======================
        // KARTU BIODATA
        // =======================
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            Column(Modifier.padding(16.dp)) {

                Text(
                    "Biodata Anggota",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(Modifier.height(12.dp))

                AboutInfoItem("Nama", member.nama)
                AboutInfoItem("NIM", member.nim)
                AboutInfoItem("Program Studi", member.prodi)
            }
        }
    }
}

@Composable
fun AboutInfoItem(label: String, value: String) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label, fontWeight = FontWeight.SemiBold)
        Text(value, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}


// =========================
// PAGE SKILLS
// =========================
@Composable
fun SkillsPage(member: Member) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {
        items(member.skills.size) { index ->
            val skill = member.skills[index]

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Star, contentDescription = null)
                    Spacer(Modifier.width(10.dp))

                    Column(Modifier.fillMaxWidth()) {
                        Text(skill.first, fontWeight = FontWeight.Bold)

                        LinearProgressIndicator(
                            progress = { skill.second }, // <-- Lambda untuk Material3 terbaru
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 6.dp),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant

                        )
                    }
                }
            }
        }
    }
}

// =========================
// PAGE CONTACT + SNACKBAR
// =========================
@Composable
fun ContactPage(member: Member) {
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {
        Text("Email: ${member.email}", fontWeight = FontWeight.Bold)
        Text("Phone: ${member.phone}", fontWeight = FontWeight.Bold)

        Spacer(Modifier.height(20.dp))

        Button(onClick = {
            scope.launch {
                snackbarHostState.showSnackbar("Message Sent!")
            }
        }) {
            Icon(Icons.Default.Email, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Send Message")
        }

        Spacer(Modifier.height(20.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Email, contentDescription = null)
            Spacer(Modifier.width(10.dp))
            Icon(Icons.Default.Phone, contentDescription = null)
        }
    }
}
